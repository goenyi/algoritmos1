#include<iostream>
#include <windows.h>


using namespace std;

//funcion para posici�n en pantalla
void pre(int x,int y){  
      HANDLE hcon;  
      hcon = GetStdHandle(STD_OUTPUT_HANDLE);  
      COORD dwPos;  
      dwPos.X = x;  
      dwPos.Y= y;  
     SetConsoleCursorPosition(hcon,dwPos);  
 }

int main() {
    // Definici�n de variables
    int Codigo;
    string nombre;
    float monto, Impuesto, tpagar;
    
    system("cls");
    pre(30,8); printf("INGRESO DE DATOS");
    pre(20,11); printf("Codigo..........");
    pre(20,12); printf("Nombre..........");
    pre(20,13); printf("Monto...........");
    pre(20,14); printf("Impuesto........");
    pre(20,15); printf("Total a pagar...");

    pre(40,11); cin>>Codigo;
    pre(40,12); cin>>nombre;    
    pre(40,13); cin>>monto;
	 
	//Calculos de valores
	Impuesto=monto*0.12;
	tpagar=monto+Impuesto;
	
    pre(40,14); cout<<Impuesto;    
    pre(40,15); cout<<tpagar;	
	pre(40,17);    
 
    system("pauses");    

}
